// function Hero() {
//   return (
//     <section>
//       <h1>Help People. Change Lives.</h1>

//       <p>
//         Every donation brings hope to someone in need.
//       </p>

//       <button>Donate Now</button>
//     </section>
//   );
// }

// export default Hero;

// 2nd improvements
// function Hero() {
//   return (
//     <section className="hero">
//       <div className="hero-content">
//         <h1>Help People. Change Lives.</h1>

//         <p>
//           Every donation creates hope for someone in need.
//         </p>

//         <div className="hero-buttons">
//           <button>Donate Now</button>
//           <button>Learn More</button>
//         </div>
//       </div>
//     </section>
//   );
// }

// export default Hero;


// 3rd improvements

// function Hero() {
//   return (
//     <section className="hero">
//       <div className="hero-content">
//         <h1>Help People. Change Lives.</h1>

//         <p>
//           Every donation creates hope for someone in need.
//         </p>

//         <div className="hero-buttons">
//           <button className="donate-btn">Donate Now</button>

//           <button className="learn-btn">Learn More</button>
//         </div>
//       </div>
//     </section>
//   );
// }

// export default Hero;

// 4th improvements

function Hero() {
  return (
    <section className="hero">
      <div className="hero-left">
        <h1>Help People. Change Lives.</h1>

        <p>
          Every donation creates hope for someone in need.
        </p>

        <div className="hero-buttons">
          <button className="donate-btn">Donate Now</button>
          <button className="learn-btn">Learn More</button>
        </div>
      </div>

      <div className="hero-right">
        <img
          src="https://images.unsplash.com/photo-1593113598332-cd288d649433?w=600"
          alt="Helping People"
        />
      </div>
    </section>
  );
}

export default Hero;