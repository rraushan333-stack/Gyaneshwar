function Navbar() {
  return (
    <nav>
      <h2>Hope Foundation</h2>

      <ul>
        <li>Home</li>
        <li>About</li>
        <li>Causes</li>
        <li>Donate</li>
        <li>Contact</li>
      </ul>
    </nav>
  );
}

export default Navbar;